#!/bin/sh
#DESCRIPTION=Ce script mets a jour votre liste de chaines

old1="login"
old2="password"
old3="loginXstream"
old4="passwordXstream"


#Vérification du user
if [ -f /usr/share/info/SPECIAL ]
then
    echo "User special"
    echo "le telechargement est en cours ..."
    echo ""
	#cp /usr/share/info/chaine_special /tmp/chaine.tar.gz
    curl -o chaine.tar.gz https://raw.githubusercontent.com/Myprio/Files/main/chaine_special.tar
	mv chaine.tar.gz /tmp/chaine.tar.gz
	new1=$(cat /usr/share/info/login.txt)
	new2=$(cat /usr/share/info/password.txt)
else	
	if [ -f /usr/share/info/IPTV ]
	then
		echo "User IPTV normal"
		echo "le telechargement est en cours ..."
		echo ""
		curl -o chaine.tar.gz https://raw.githubusercontent.com/Myprio/Files/main/chaine_ip.tar
		mv chaine.tar.gz /tmp/chaine.tar.gz
		new1=$(cat /usr/share/info/loginIPTV)
		new2=$(cat /usr/share/info/passwordIPTV)
	else
		if [ -f /usr/share/info/IPTV_SPECIAL ]
		then
			echo "User IPTV special"
			echo "le telechargement est en cours ..."
			echo ""
			#cp /usr/share/info/chaine_ip_special /tmp/chaine.tar.gz
			curl -o chaine.tar.gz https://raw.githubusercontent.com/Myprio/Files/main/chaine_ip_special.tar
			mv chaine.tar.gz /tmp/chaine.tar.gz
			new1=$(cat /usr/share/info/loginIPTV)
			new2=$(cat /usr/share/info/passwordIPTV)
		else
			if [ -f /usr/share/info/INFINITY ]
			then
				echo "User infinity"
				echo "le telechargement est en cours ..."
				echo ""
				curl -o chaine.tar.gz https://raw.githubusercontent.com/Myprio/Files/main/chaine_infinity.tar
				mv chaine.tar.gz /tmp/chaine.tar.gz
				new1=$(cat /usr/share/info/login.txt)
				new2=$(cat /usr/share/info/password.txt)
			else
				echo "User premium"
				echo "le telechargement est en cours ..."
				echo ""
				curl -o chaine.tar.gz https://raw.githubusercontent.com/Myprio/Files/main/chaine_prem.tar
				mv chaine.tar.gz /tmp/chaine.tar.gz
				new1=$(cat /usr/share/info/login.txt)
				new2=$(cat /usr/share/info/password.txt)
			fi	
		fi
	fi	
fi	

#Décompression du fichier
rm -f /etc/enigma2/*.tv
tar -xzf /tmp/chaine.tar.gz -C /
rm -f /tmp/chaine.tar.gz
sleep 3

chmod 777 /usr/script/skrypty/*.sh

if [ -f /usr/lib/enigma2/python/Plugins/Extensions/XStreamity ]
then
	echo " "
else
	/usr/script/skrypty/install_xstreamity
fi	


#Mise à jour des IPTV
echo "Ceci va mettre a jour vos chaines IPTV"
find /etc/enigma2/*.tv -exec sed -i "s/$old1/$new1/g" '{}' \;
find /etc/enigma2/*.tv -exec sed -i "s/$old2/$new2/g" '{}' \;
find /etc/enigma2/xstreamity/playlists.txt -exec sed -i "s/$old3/$new1/g" '{}' \;
find /etc/enigma2/xstreamity/playlists.txt -exec sed -i "s/$old4/$new2/g" '{}' \;


sleep 3
echo "Vos chaînes iptv sont maintenant à jour"
echo "Votre décodeur va maintenant redémarrer"
echo "Veuillez patientez svp...."

sleep 3
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0


rm /tmp/login.txt
rm /tmp/password.txt


echo "Vous disposez desormais de la dernier liste de favoris"
sleep 3
killall -9 enigma2

exit 0
