#!/bin/sh
#DESCRIPTION=Ce script mets a jour vos bouquets pour le streaming.

opkg update

if ( opkg list_installed *bash* | grep "*bash*" ) || ( opkg list_installed bash* | grep "bash*" )
then
 echo "bash already installed"
else
echo "1" > /tmp/update.txt
opkg update
opkg install bash
fi

if ( opkg list_installed *cron* | grep "*cron*" ) || ( opkg list_installed cron* | grep "cron*" ) || ( opkg list_installed *cron* | grep "cron*" )
then
 echo "cron already installed"
else
	if [ -f /tmp/update.txt ]
	then
	opkg install cron
	opkg install busybox-cron
	else
	opkg update
	echo "1" > /tmp/update.txt
	opkg install cron
	opkg install busybox-cron
	fi
fi

if ( opkg list_installed *curl* | grep "*curl*" ) || ( opkg list_installed curl* | grep "curl*" ) || ( opkg list_installed *curl* | grep "curl*" )
then
 echo "curl already installed"
else
        if [ -f /tmp/update.txt ]
        then
        opkg install curl
        else
        opkg update
        echo "1" > /tmp/update.txt
        opkg install curl
        fi
fi


if ( opkg list_installed *ntpdate* | grep "*ntpdate" ) || ( opkg list_installed ntpdate* | grep "ntpdate*" )
then
 echo "ntpdate already installed"
else
	if [ -f /tmp/update.txt ]
	then
	opkg install ntpdate
	else
	opkg update
	echo "1" > /tmp/update.txt
	opkg install ntpdate
	fi
fi

ntpdate 0.pool.ntp.org

curl -o /tmp/xstreamity.ipk https://raw.githubusercontent.com/Myprio/Files/main/xstreamity
chmod 777 /tmp/xstreamity.ipk
opkg install /tmp/xstreamity.ipk

rm /tmp/xstreamity.ipk

#killall -9 enigma2
exit
