#!/bin/sh
#DESCRIPTION=Ce script mets a jour vos bouquets pour le streaming.

opkg update

if ( opkg list_installed *bash* | grep "*bash*" ) || ( opkg list_installed bash* | grep "bash*" )
then
 echo "bash already installed"
else
echo "1" > /tmp/update.txt
opkg update
opkg install bash
fi

if ( opkg list_installed *cron* | grep "*cron*" ) || ( opkg list_installed cron* | grep "cron*" ) || ( opkg list_installed *cron* | grep "cron*" )
then
 echo "cron already installed"
else
	if [ -f /tmp/update.txt ]
	then
	opkg install cron
	opkg install busybox-cron
	else
	opkg update
	echo "1" > /tmp/update.txt
	opkg install cron
	opkg install busybox-cron
	fi
fi

if ( opkg list_installed *curl* | grep "*curl*" ) || ( opkg list_installed curl* | grep "curl*" ) || ( opkg list_installed *curl* | grep "curl*" )
then
 echo "curl already installed"
else
        if [ -f /tmp/update.txt ]
        then
        opkg install curl
        else
        opkg update
        echo "1" > /tmp/update.txt
        opkg install curl
        fi
fi


if ( opkg list_installed *ntpdate* | grep "*ntpdate" ) || ( opkg list_installed ntpdate* | grep "ntpdate*" )
then
 echo "ntpdate already installed"
else
	if [ -f /tmp/update.txt ]
	then
	opkg install ntpdate
	else
	opkg update
	echo "1" > /tmp/update.txt
	opkg install ntpdate
	fi
fi

ntpdate 0.pool.ntp.org

curl -o /tmp/xstreamity.ipk https://raw.githubusercontent.com/Myprio/Files/main/xstreamity
chmod 777 /tmp/xstreamity.ipk
opkg install /tmp/xstreamity.ipk

if [ -f /usr/lib/enigma2/python/Plugins/Extensions/PremiumPlayer/version.txt ]
then
	chaine="config.plugins.PremiumPlayer.main=true" 
	chaine2="config.plugins.PremiumPlayer.main=false"
	if grep -q config.plugins.PremiumPlayer.main=true /etc/enigma2/settings ; then
		echo "premium play trouver dans settings"
		find /etc/enigma2/settings -exec sed -i "s/$chaine/$chaine2/g" '{}' \;
	else	
		echo "config.plugins.PremiumPlayer.main=false" >> /etc/enigma2/settings
	fi
fi
	
if [ -f /usr/lib/enigma2/python/Plugins/Extensions/XCplugin/version.txt ]
then
	chaine="config.plugins.XCplugin.main=true" 
	chaine2="config.plugins.XCplugin.main=false"
	if grep -q config.plugins.XCplugin.main=true /etc/enigma2/settings ; then
		echo "XCplugin trouver dans settings"
		find /etc/enigma2/settings -exec sed -i "s/$chaine/$chaine2/g" '{}' \;
	else	
		echo "config.plugins.XCplugin.main=false" >> /etc/enigma2/settings
	fi
fi

echo "config.plugins.XStreamity.main=true" >> /etc/enigma2/settings

rm /tmp/xstreamity.ipk

#killall -9 enigma2
exit
