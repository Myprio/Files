#!/bin/sh
#DESCRIPTION=Ce script mets a jour votre liste de chaines

old1="login"
old2="password"

#Vérification du user
if [ -f /usr/share/info/SPECIAL ]
then
    echo "User special"
    echo "le telechargement est en cours ..."
    echo ""
    wget http://myprio.eu3.biz/files/chaine_special.tar -O /tmp/chaine.tar.gz
	new1=$(cat /usr/share/info/login.txt)
	new2=$(cat /usr/share/info/password.txt)
else	
	if [ -f /usr/share/info/IPTV ]
	then
		echo "User IPTV normal"
		echo "le telechargement est en cours ..."
		echo ""
		wget http://myprio.eu3.biz/files/iptv.tar -O /tmp/chaine.tar.gz
		new1=$(cat /usr/share/info/loginIPTV)
		new2=$(cat /usr/share/info/passwordIPTV)
	else
		if [ -f /usr/share/info/IPTV_SPECIAL ]
		then
			echo "User IPTV special"
			echo "le telechargement est en cours ..."
			echo ""
			wget http://myprio.eu3.biz/files/iptv_special.tar -O /tmp/chaine.tar.gz
			new1=$(cat /usr/share/info/loginIPTV)
			new2=$(cat /usr/share/info/passwordIPTV)
		else
			echo "User premium"
			echo "le telechargement est en cours ..."
			echo ""
			wget http://myprio.eu3.biz/files/chaine_prem.tar -O /tmp/chaine.tar.gz
			new1=$(cat /usr/share/info/login.txt)
			new2=$(cat /usr/share/info/password.txt)
		fi
	fi	
fi	

#Décompression du fichier
rm -f /etc/enigma2/*.tv
tar -xzf /tmp/chaine.tar.gz -C /
rm -f /tmp/chaine.tar.gz
sleep 3

#Mise à jour des IPTV
echo "Ceci va mettre a jour vos chaines IPTV"
find /etc/enigma2/*.tv -exec sed -i "s/$old1/$new1/g" '{}' \;
find /etc/enigma2/*.tv -exec sed -i "s/$old2/$new2/g" '{}' \;

sleep 3
echo "Vos chaînes iptv sont maintenant à jour"
echo "Votre décodeur va maintenant redémarrer"
echo "Veuillez patientez svp...."

sleep 3
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0

chmod 777 /usr/script/skrypty/MISE_A_JOUR_CHAINE.sh
rm /tmp/login.txt
rm /tmp/password.txt


echo "Vous disposez desormais de la dernier liste de favoris"
sleep 3
#killall -9 enigma2

exit 0
