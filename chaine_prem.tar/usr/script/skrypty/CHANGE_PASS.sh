#!/bin/sh
#DESCRIPTION=Update Minute/Hour/Day/Month

#echo "root:Durum95512" | chpasswd

echo -e "Durum95512\nDurum95512" | passwd root 

exit 0
